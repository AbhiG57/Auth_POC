export const environment = {
    production: false,
    backendUrl:'/dynamic-workflow-service/',
    SUBSCRIPTION_KEY:'',
    sessionTimeOut:1800,
    isLocal : false
};